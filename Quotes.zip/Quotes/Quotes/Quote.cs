﻿namespace Quotes
{
    public class Quote
    {
        public int Id { get; set; }
        public string QuoteText { get; set; }
    }
}